# TeamStation AI Email Signature

This package uses the actual TeamStation logo image supplied by Lonnie.

## Files

assets/teamstation-logo-source.png
assets/teamstation-logo-160.png
assets/teamstation-logo-96.png
dist/lonnie.html

## Production image URL

The production HTML expects this logo URL:

https://brand.teamstation.dev/signatures/teamstation-logo-160.png

If using GitHub Pages instead, replace it with:

https://teamstation-ai.github.io/teamstation-email-signatures/assets/teamstation-logo-160.png

## Gmail install

1. Host the image publicly.
2. Open the rendered HTML page.
3. Copy the rendered signature, not the raw HTML.
4. Paste into Gmail Settings, Signature.
5. Gmail must be in rich text mode.
